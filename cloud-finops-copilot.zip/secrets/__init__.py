"""Secrets package for runtime credential retrieval."""

from .secret_manager import SecretManagerClient, global_secret_manager

__all__ = ["SecretManagerClient", "global_secret_manager"]
